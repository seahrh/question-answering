__all__ = []

from .arcface import *

__all__ += arcface.__all__  # type: ignore  # module name is not defined
